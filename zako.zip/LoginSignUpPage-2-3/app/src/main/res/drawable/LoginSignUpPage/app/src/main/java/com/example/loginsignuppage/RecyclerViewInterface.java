package com.example.loginsignuppage;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}

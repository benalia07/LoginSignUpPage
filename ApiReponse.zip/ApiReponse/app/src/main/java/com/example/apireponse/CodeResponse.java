package com.example.apireponse;

public class CodeResponse {

        private String code;

        // Ajoutez les autres propriétés nécessaires

        public String getCode() {
            return code;
        }

        // Ajoutez les autres méthodes nécessaires
    }


package com.example.apireponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface CodeApiService {

        @GET("api/Codes/GetCode")
        Call<CodeResponse> getCode(@Query("prefix") int prefix, @Query("type") int type, @Query("valeur") int valeur);

        @GET("api/Codes/checkCode")
        Call<Boolean> checkCode(@Query("code") String code);

        // Ajoutez les autres méthodes d'appel d'API nécessaires
    }


package com.example.apireponse;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private EditText prefixEditText;
    private EditText typeEditText;
    private EditText valeurEditText;
    private Button genererCodeButton;
    private Button checkCodeButton;
    private static TextView resultTextView;

    private static final String BASE_URL = "http://inventaire-001-site1.atempurl.com/Inv?numInv=145";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefixEditText = findViewById(R.id.prefixEditText);
        typeEditText = findViewById(R.id.typeEditText);
        valeurEditText = findViewById(R.id.valeurEditText);
        genererCodeButton = findViewById(R.id.genererCodeButton);
        checkCodeButton = findViewById(R.id.checkCodeButton);
        resultTextView = findViewById(R.id.resultTextView);

        genererCodeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new FetchCodeTask().execute();
            }
        });

        checkCodeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String code = prefixEditText.getText().toString();
                String url = BASE_URL;
                new CheckCodeTask().execute(url);
            }
        });
    }

    private class FetchCodeTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            String response = "";
            try {
                URL url = new URL(BASE_URL);

                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setDoOutput(true);

                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        response += line;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            return response;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            parseResponse(s);
        }
    }

    private static class CheckCodeTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... urls) {
            String response = "";
            try {
                URL url = new URL(urls[0]);

                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        response += line;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            return response;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            parseResponse(s);
        }
    }

    private static void parseResponse(String response) {
        if (response != null && !response.isEmpty()) {
            try {
                JsonParser parser = new JsonParser();
                JsonObject jsonObject = parser.parse(response).getAsJsonObject();

                String nomProduit = jsonObject.get("nomProduit").getAsString();
                String nomStructure = jsonObject.get("nomStructure").getAsString();
                String dateEntree = jsonObject.get("dateEntree").getAsString();
                int prixAchat = jsonObject.get("prixAchat").getAsInt();
                int etat = jsonObject.get("etat").getAsInt();

                String result = "Nom Produit: " + nomProduit + "\n"
                        + "nomStructure: " + nomStructure + "\n"
                        + "dateEntree: " + dateEntree + "\n"
                        + "prixAchat: " + prixAchat + "\n"
                        + "etat: " + etat;

                resultTextView.setText(result);
            } catch (Exception e) {
                e.printStackTrace();
                resultTextView.setText("Failed to parse response");
            }
        } else {
            resultTextView.setText("No response received");
        }
    }
}

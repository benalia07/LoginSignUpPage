Flight(1,alger,paris,10,12,200). 
Flight(2,paris,boston,06,16,100). 
Flight(3,alger,lyon,9,11,180).
Flight(4,paris,biskra,10,13,200).
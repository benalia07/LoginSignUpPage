package com.example.loginsignuppage;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;

import java.util.ArrayList;

public class OrderPage extends AppCompatActivity {
Button Buy;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_page);
        Buy=findViewById(R.id.BuyBtn);
        Buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             
            }

        });
        String title = getIntent().getStringExtra("TITLE");
        String description = getIntent().getStringExtra("DESCRIPTION");
        String image = getIntent().getStringExtra("IMAGE");
        ArrayList<String> images = getIntent().getStringArrayListExtra("IMAGES");
        ImageSlider imageSlider = findViewById(R.id.imagesSlider);
        ImageView imageView = findViewById(R.id.back);

        TextView textView = findViewById(R.id.title);
        textView.setText(title);

        TextView textView1 = findViewById(R.id.description);
        textView1.setText(description);


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        ArrayList<SlideModel> slideModels = new ArrayList<>();
        slideModels.add(new SlideModel(image, ScaleTypes.FIT));
        imageSlider.setImageList(slideModels, ScaleTypes.FIT);
}
}
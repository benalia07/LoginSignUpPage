package com.example.loginsignuppage;

public interface RecyclerViewInterface {
    void onItemClick(int position);

    abstract void onItemClick2(int position);
}
